export default function Login() {
  return <div className="p-6 text-gray-500">Login — em construção</div>
}
